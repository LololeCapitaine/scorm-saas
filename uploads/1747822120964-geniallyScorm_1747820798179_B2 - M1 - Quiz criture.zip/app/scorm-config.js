
    window.geniallyElearningPresetData = {
      passingPercentage: 100
    };
      