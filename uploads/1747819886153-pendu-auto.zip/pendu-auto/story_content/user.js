function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5wMCV2cVwQ7":
        Script1();
        break;
      case "6HIsM5oiOe0":
        Script2();
        break;
      case "6Tp1Xp0AhsZ":
        Script3();
        break;
      case "5xr0NUYqPh0":
        Script4();
        break;
      case "6RBXQZ4bU48":
        Script5();
        break;
      case "5vFLmUV2P8q":
        Script6();
        break;
      case "6aOavzliGMo":
        Script7();
        break;
      case "5rwB1l6vK1V":
        Script8();
        break;
      case "5lu7N4p4Q1C":
        Script9();
        break;
      case "6MU3PgCrgbT":
        Script10();
        break;
      case "5VIc7CchmZg":
        Script11();
        break;
      case "6l4HTltNZKu":
        Script12();
        break;
      case "5npUFdUm7Gm":
        Script13();
        break;
      case "5vYTGiwwvsN":
        Script14();
        break;
      case "5nWm5UWF83Y":
        Script15();
        break;
      case "6fhcGo3qf26":
        Script16();
        break;
      case "63tfI3AyNT6":
        Script17();
        break;
      case "6kaQQ0VkfnT":
        Script18();
        break;
      case "6DdTYuFJzTN":
        Script19();
        break;
      case "5geFfUzv5w0":
        Script20();
        break;
      case "6e1WBjiGC24":
        Script21();
        break;
      case "5XPJ0AcbA3d":
        Script22();
        break;
      case "6OJFJWUTCVF":
        Script23();
        break;
      case "5saIYquovqd":
        Script24();
        break;
      case "5ruh2gcjChM":
        Script25();
        break;
      case "67SuMd6mOiF":
        Script26();
        break;
      case "60jqnO82Uq0":
        Script27();
        break;
      case "6dUgkdhnFKN":
        Script28();
        break;
      case "6G0h1aikG6C":
        Script29();
        break;
      case "6WeX2WQKHZZ":
        Script30();
        break;
      case "5rEFTkr81Fy":
        Script31();
        break;
      case "6gBS3ESwaAI":
        Script32();
        break;
      case "69RRl8vpXb3":
        Script33();
        break;
      case "6gruzGKtOpO":
        Script34();
        break;
      case "5mZXcfJzcD0":
        Script35();
        break;
      case "5ncAEnpRWJq":
        Script36();
        break;
      case "6dxN2omp2KV":
        Script37();
        break;
      case "63xIwwf5nEq":
        Script38();
        break;
      case "6o7GbnYL984":
        Script39();
        break;
      case "5gxgWGO7YQQ":
        Script40();
        break;
      case "6aZnRo0v5Cz":
        Script41();
        break;
      case "6lbfdK9H0sl":
        Script42();
        break;
      case "6hr0ZFsKUDt":
        Script43();
        break;
      case "6FqRXmiKP7N":
        Script44();
        break;
      case "6hpDBA8kuJU":
        Script45();
        break;
      case "6g12eYkOYKM":
        Script46();
        break;
      case "6AUOY3vhzLs":
        Script47();
        break;
      case "6D6emt4Wegf":
        Script48();
        break;
      case "6EGLZ9XMeP2":
        Script49();
        break;
      case "6ZA5RLPkuq7":
        Script50();
        break;
      case "5tdTW1LmqK7":
        Script51();
        break;
      case "6UKAau52r3w":
        Script52();
        break;
      case "6JhwonCPfTG":
        Script53();
        break;
      case "6CLpgPIimtX":
        Script54();
        break;
      case "6fp7LzJN3Vm":
        Script55();
        break;
      case "6gCsk2T9nu9":
        Script56();
        break;
      case "6hJ0FXZrTeH":
        Script57();
        break;
      case "5iednrpF3xO":
        Script58();
        break;
      case "6Nb6tZlA05k":
        Script59();
        break;
      case "5dt49JV5fJz":
        Script60();
        break;
      case "5r4E2NZTVhf":
        Script61();
        break;
      case "5dUcTGgJnrO":
        Script62();
        break;
      case "6GOhbKFoPjr":
        Script63();
        break;
      case "6cNXQVhrKOF":
        Script64();
        break;
      case "5dQaWGrK5ft":
        Script65();
        break;
      case "6Xxm26vla3U":
        Script66();
        break;
      case "6ZAgqFcrDfO":
        Script67();
        break;
      case "5gTQfRJ0ynN":
        Script68();
        break;
      case "6r45J6M094Q":
        Script69();
        break;
      case "5fV8iJMj7Op":
        Script70();
        break;
      case "64kadxfDu06":
        Script71();
        break;
      case "5qXoqpdMdSG":
        Script72();
        break;
      case "6XIlGdePI3l":
        Script73();
        break;
      case "6MIkGIDF6nf":
        Script74();
        break;
      case "5o4xxXhEjR0":
        Script75();
        break;
      case "5cpHIFku3lW":
        Script76();
        break;
      case "5WiTgGekc7g":
        Script77();
        break;
      case "5jYAI6uYWDX":
        Script78();
        break;
      case "5wyqlWQjtdo":
        Script79();
        break;
      case "6WYVUNlkBlM":
        Script80();
        break;
      case "660Y0YtYTyi":
        Script81();
        break;
      case "5rpjgNtpJim":
        Script82();
        break;
      case "62mfySILH5t":
        Script83();
        break;
      case "6kYyGimBaN2":
        Script84();
        break;
      case "6cVefy4VNzC":
        Script85();
        break;
      case "65vl4ddbWZb":
        Script86();
        break;
      case "5bCGIGZtUlq":
        Script87();
        break;
      case "6c51kZho8Cb":
        Script88();
        break;
      case "5ZiDcVHBbXa":
        Script89();
        break;
      case "6rX3EAV7e1w":
        Script90();
        break;
      case "5wjhMrF7aJg":
        Script91();
        break;
      case "69xDIq9Lfj5":
        Script92();
        break;
      case "63Rh2hbraBB":
        Script93();
        break;
      case "5rfabK8fQDl":
        Script94();
        break;
      case "615y7mPYPoJ":
        Script95();
        break;
      case "6q18OSbmtaY":
        Script96();
        break;
      case "6GUgDRMVzDj":
        Script97();
        break;
      case "6rCrwpThnq7":
        Script98();
        break;
      case "6h8CLbD3ul6":
        Script99();
        break;
      case "6gqJ0VG079l":
        Script100();
        break;
      case "62HMPTSaVJn":
        Script101();
        break;
      case "5q1yblJmLX1":
        Script102();
        break;
      case "5Uw2faI9y6z":
        Script103();
        break;
      case "5t98O9vleus":
        Script104();
        break;
      case "5cBKkGoXqza":
        Script105();
        break;
      case "6ilkA7PSUIQ":
        Script106();
        break;
      case "6IA9ZtHrwYb":
        Script107();
        break;
      case "6IIwHyHA3OM":
        Script108();
        break;
      case "6axYA7bm4ve":
        Script109();
        break;
      case "5bkIMxjWAuZ":
        Script110();
        break;
      case "6BylIcvMhLt":
        Script111();
        break;
      case "6WHYRSviznQ":
        Script112();
        break;
      case "6FikRjqgxN9":
        Script113();
        break;
      case "6alFrmrEISN":
        Script114();
        break;
      case "5q8VLzGMcBE":
        Script115();
        break;
      case "6GLT3RzHrcD":
        Script116();
        break;
      case "5raEoOTPGB1":
        Script117();
        break;
      case "5wPPwvLXn0k":
        Script118();
        break;
      case "6cWUtAw1ZQG":
        Script119();
        break;
      case "6Mhounop2aM":
        Script120();
        break;
      case "5iy9G8sgfZV":
        Script121();
        break;
      case "6XIfPSFVQdT":
        Script122();
        break;
      case "6ASDQgDGid6":
        Script123();
        break;
      case "6RTiTIonDTT":
        Script124();
        break;
      case "6eEACzp9gUs":
        Script125();
        break;
      case "6DVB00lkXgj":
        Script126();
        break;
      case "5llvoEdupRj":
        Script127();
        break;
      case "6jhjTg4dFVg":
        Script128();
        break;
      case "5tJApnh61EQ":
        Script129();
        break;
      case "5aL9AfUPtxB":
        Script130();
        break;
      case "6StHhIMFFIK":
        Script131();
        break;
      case "6ffuEq21ukw":
        Script132();
        break;
      case "5VtSbE4WfmZ":
        Script133();
        break;
      case "6a06HkjR1Sj":
        Script134();
        break;
      case "5oJbcHrvyq5":
        Script135();
        break;
      case "5WWg5RIr7KM":
        Script136();
        break;
      case "6EUISsh1lX6":
        Script137();
        break;
      case "6cTBYvuf7V1":
        Script138();
        break;
      case "64ZGeTz4ppp":
        Script139();
        break;
      case "5nGQz9Zs2Dl":
        Script140();
        break;
      case "6qALJnswQ0j":
        Script141();
        break;
      case "61HZhxwhKhZ":
        Script142();
        break;
      case "6ZXJgRo6INe":
        Script143();
        break;
      case "5vNX2xkc07m":
        Script144();
        break;
      case "6fDJ0Z3rW6O":
        Script145();
        break;
      case "6ht0uB7W3XY":
        Script146();
        break;
      case "6EwfLB79K9c":
        Script147();
        break;
      case "5eBq64YRgAh":
        Script148();
        break;
      case "6SwyuB5ce3C":
        Script149();
        break;
      case "5oM31JLEKIT":
        Script150();
        break;
      case "69SmvuaFSCD":
        Script151();
        break;
      case "6LpnruM0QKF":
        Script152();
        break;
      case "60YB5Zb8JL4":
        Script153();
        break;
      case "5qHagh0XfVh":
        Script154();
        break;
      case "5ZljlGRGi47":
        Script155();
        break;
      case "6CELsvEn29G":
        Script156();
        break;
      case "5ZqIl12hz8d":
        Script157();
        break;
      case "61Xu4MOrgKJ":
        Script158();
        break;
  }
}

window.InitExecuteScripts = function()
{
var player = GetPlayer();
var object = player.object;
var addToTimeline = player.addToTimeline;
var setVar = player.SetVar;
var getVar = player.GetVar;
window.Script1 = function()
{
  // Réinitialiser "0_guess_1" à "0_guess_14" avec la valeur "_"
for(var i = 1; i <= 14; i++) {
    player.SetVar("0_guess_" + i, "_");
}

// Réinitialiser les variables "A" à "Z" à la valeur "Faux"
var letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var i = 0; i < letters.length; i++) {
    player.SetVar(letters.charAt(i), false);
}

// Réinitialiser "verifA" à "verifZ" à la valeur "Faux"
for(var i = 0; i < letters.length; i++) {
    player.SetVar("verif" + letters.charAt(i), false);
}

// Réinitialiser "mot" à une valeur vide
player.SetVar("mot", "");

// Réinitialiser "0_pendu" à la valeur "11"
player.SetVar("0_pendu", 11);

// Réinitialiser "letter1" à "letter14" à une valeur vide
for(var i = 1; i <= 14; i++) {
    player.SetVar("letter" + i, "");
}

}

window.Script2 = function()
{
  // Récupération de la chaîne de caractères saisie par l'utilisateur
var userInput = player.GetVar("mot");

// Séparation de la chaîne en un tableau de caractères
var characters = userInput.split('');

// Affectation de chaque caractère à une variable Storyline et basculement de la variable Vrai/Faux correspondante
for(var i = 0; i < characters.length; i++) {
    // Stocker chaque caractère dans une variable Storyline
    player.SetVar("letter" + (i+1), characters[i]);

    // Basculement de la variable Vrai/Faux correspondante à "vrai"
    // Convertir la lettre en majuscule pour correspondre aux noms des variables
    var currentLetter = characters[i].toUpperCase();
    // Assurez-vous que les noms de vos variables Vrai/Faux correspondent à ce format : "A", "B", "C", etc.
    player.SetVar(currentLetter, true);
}







// Boucler sur les variables "letter" de 1 à 14
for(var i = 1; i <= 14; i++) {
    // Construire le nom de la variable pour la lettre actuelle
    var letterVarName = "letter" + i;
    
    // Récupérer la valeur de la variable de lettre actuelle
    var currentLetter = player.GetVar(letterVarName);
    
    // Convertir la valeur en majuscule
    var letterInUpperCase = currentLetter.toUpperCase();
    
    // Mettre à jour la variable "letter" avec la valeur en majuscule
    player.SetVar(letterVarName, letterInUpperCase);
}











// Initialiser le compteur à 0
var nombreDeLettres = 0;

// Boucler sur les variables "letter" de 1 à 14
for(var i = 1; i <= 14; i++) {
    // Construire le nom de la variable pour la lettre actuelle
    var letterVarName = "letter" + i;
    
    // Récupérer la valeur de la variable de lettre actuelle
    var currentLetter = player.GetVar(letterVarName);
    
    // Vérifier si la variable de lettre n'est pas vide
    if(currentLetter !== "") {
        // Incrémenter le compteur si la lettre n'est pas vide
        nombreDeLettres++;
    }
}

// Mettre à jour la variable "nombreDeLettres" dans Storyline avec le compteur calculé
player.SetVar("nombreDeLettres", nombreDeLettres);

}

window.Script3 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script4 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script5 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script6 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script7 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script8 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script9 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script10 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script11 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script12 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script13 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script14 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script15 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script16 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script17 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script18 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script19 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script20 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script21 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script22 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script23 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script24 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script25 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script26 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script27 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script28 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script29 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script30 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script31 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script32 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script33 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script34 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script35 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script36 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script37 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script38 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script39 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script40 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script41 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script42 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script43 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script44 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script45 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script46 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script47 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script48 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script49 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script50 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script51 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script52 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script53 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script54 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script55 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script56 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script57 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script58 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script59 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script60 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script61 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script62 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script63 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script64 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script65 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script66 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script67 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script68 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script69 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script70 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script71 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script72 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script73 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script74 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script75 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script76 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script77 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script78 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script79 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script80 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script81 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script82 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script83 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script84 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script85 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script86 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script87 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script88 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script89 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script90 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script91 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script92 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script93 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script94 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script95 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script96 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script97 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script98 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script99 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script100 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script101 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script102 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script103 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script104 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script105 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script106 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script107 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script108 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script109 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script110 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script111 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script112 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script113 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script114 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script115 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script116 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script117 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script118 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script119 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script120 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script121 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script122 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script123 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script124 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script125 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script126 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script127 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script128 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script129 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script130 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script131 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script132 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script133 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script134 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script135 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script136 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script137 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script138 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script139 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script140 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script141 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script142 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script143 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script144 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script145 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script146 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script147 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script148 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script149 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script150 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script151 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script152 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script153 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script154 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script155 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script156 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script157 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

window.Script158 = function()
{
  // Boucle pour chaque lettre de l'alphabet
var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
for(var j = 0; j < alphabet.length; j++) {
    var currentAlphabetLetter = alphabet.charAt(j);
    // Vérifier si la vérification pour la lettre actuelle est vraie (par exemple, "verifA", "verifB", ...)
    var verifVarName = "verif" + currentAlphabetLetter;
    var verif = player.GetVar(verifVarName);
    
    if(verif) {
        // Boucle de "letter1" à "letter14"
        for(var i = 1; i <= 14; i++) {
            // Construire le nom de la variable pour la lettre actuelle
            var letterVarName = "letter" + i;
            // Récupérer la valeur de la variable de lettre actuelle
            var currentLetter = player.GetVar(letterVarName);
            
            // Vérifier si la lettre actuelle est égale à la lettre de l'alphabet en cours de traitement
            if(currentLetter === currentAlphabetLetter) {
                // Construire le nom de la variable guess correspondante avec le nouveau format
                var guessVarName = "0_guess_" + i;
                // Affecter la lettre de l'alphabet à la variable guess correspondante
                player.SetVar(guessVarName, currentAlphabetLetter);
            }
        }
    }
}

}

};
